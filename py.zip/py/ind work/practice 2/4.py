import math
x = 1
y = 4
z = 3   
a = math.tan(y)
b = 1/a
c = math.fabs(b+6)
e = c ** (1. / 3.)
f = x+1
p = math.pow(f, 3)
h = 4*y-2*z
t = p / h
o = math.sqrt(t)

m = e + o

print(m)

input()
