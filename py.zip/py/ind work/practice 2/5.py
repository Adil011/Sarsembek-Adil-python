import math
x = 3
y = 0.2
a = 5*x*y
b = math.pow(x, 3) - 4
c = a / b
p = math.pow(x, 2)
d = math.exp(p)
e = math.pow(math.cos(y), 2) - math.pow(y, 2)
f = math.sqrt(e)
g = c + d + f 

print(g)

input()
