import math
x = 0.5
y = 2
b = math.asin(math.pow(x, 3)) - 6
c = math.cos(4*y) - math.sin(4*x)
a = b / (8 * c)
print(a)

input()
