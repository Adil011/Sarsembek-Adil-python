import math
a = int(input())
b = int(input())
h = int(input())
z = ((math.pow(a,2) + b) * h) / (2*(a-b)+4)
print(z)
input()