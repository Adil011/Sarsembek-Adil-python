import math
x = 3
y = 1
z = 2
a = math.pow(4, x*y)
b = math.pow(x, y*z)
c = math.pow(x*y, z)
d = a - b + c

print(d)

input()
