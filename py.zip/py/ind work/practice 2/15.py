import math
a = int(input('a = '))
b = int(input('b = '))
z = math.sqrt(math.pow(a, 2) + math.pow(b, 2))
print(z)
input()