import math
x = 2
y = 2
z = 1
c = math.pow(x, 2)
b = math.sqrt(0.6*x*y*z) + math.pow(y, c) - math.exp(math.pow(math.sin(2*x), 2))
print(b)

input()
