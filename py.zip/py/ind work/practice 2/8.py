import math
x = 2
y = 2
z = 1
a = math.fabs(x)
m = (4 * a - x*y*math.pow(z, 2)) / (x + math.exp(y*x) - 2*y*z)

print(m)

input()
