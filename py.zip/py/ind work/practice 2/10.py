import math
x = 3
y = 5
z = 3
g = 2*3*4 / math.pow(math.sin(x), 3) + math.pow(math.tan(y), 3)
a = math.sqrt(math.pow(z, x-y))
p = g - a

print(p)

input()
