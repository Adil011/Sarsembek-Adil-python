import math
x = 3
y = 5
a = math.fabs(y)
d = math.sqrt(a)
b = math.pow(math.atan(math.log10(x)), 2)
c = math.pow(x, y) - y + 1
p = b / c
g = d + p

print(g)

input()
