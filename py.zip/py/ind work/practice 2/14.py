import math
x = 2
y = 1
z = 3
c = math.fabs(math.log10(math.pow(x, 3))) + math.exp(2*x)
b = x + 3.4
d = math.pow(1/math.tan(3/(x*y*z)), 3)
a = c / b - d
print(a)

input()
