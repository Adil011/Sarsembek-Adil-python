import math
x = 2
y = 1
g = math.pow(x, y)
f = math.pow(g, x)
h = math.pow(x, g)
e = math.pow(x, 4)
z = f + h - e
print(z)

input()
