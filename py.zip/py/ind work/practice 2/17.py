import math
r = int(input("R = "))
s = math.pi * math.pow(r, 2)
print("S = ", s)
input()