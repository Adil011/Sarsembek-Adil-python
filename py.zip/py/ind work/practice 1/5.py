i=34
a=67
while i<=67:
    if i%2==0:
        print(i)
    i+=1