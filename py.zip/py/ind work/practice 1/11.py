import math
print("Guess the number, then")
print("multiply the planned number by 5")
print("add 8")
print("multiply the sum by 2")
print()
a=int(input("Enter the value that you got: "))
print()
b= ((a/2)-8)/5
print("Your number is: ",5)