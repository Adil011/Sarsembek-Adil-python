x=14
if x>10 and x!=12:
    if x<=15 or x==18:
        print("True")