for number in range(1,101):
   if(number!=50 and number!=99):
       print(number)