a=int(input("Enter first num: "))
b=int(input("Enter second num: "))
c=input("Choose operation (+,-,*,/): ")
if c=='+':
    print("Result: ", a+b)
elif c=='-':
    print("Result: ", a-b)
elif c=='*':
    print("Result: ", a*b)
elif c=='/':
    print("Result: ", a/b)