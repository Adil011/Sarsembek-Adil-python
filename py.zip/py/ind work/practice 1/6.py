a=6

while True:
    num = int(input("Enter the num: "))
    if num==a:
        print("You guessed it!")