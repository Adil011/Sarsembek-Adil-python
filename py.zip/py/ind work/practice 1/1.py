a = input('Your last name, first name? ')
b = input('"How old are you? ')
c = input('Where do you live? ')
print('Name:', a)
print('Age:', b)
print('Live:', c)

input()