import math

a=int(input("Enter integer num: "))

b=math.pow(a,2)

a1=math.pow(a,2)/3

a2=(math.pow(a,2)+4)/6

a3=(math.sqrt(b+4))/4

a4= (math.sqrt(math.pow(b+4,3)))/4

a5=a1+a2+a3+a4

print(a5)